package com.grabsend.app

import android.content.Context
import android.graphics.Bitmap
import android.os.SystemClock
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.sqrt

/**
 * Returns "finger spread ratio": average wrist->fingertip distance divided by wrist->middle-knuckle
 * distance. Small (<~1.3) = fist, large (>~1.6) = open hand. Null = no hand.
 */
class HandTracker(ctx: Context, model: File) {
    private val landmarker: HandLandmarker
    private var lastTs = 0L

    init {
        val bytes = model.readBytes()
        val buf = ByteBuffer.allocateDirect(bytes.size).order(ByteOrder.nativeOrder())
        buf.put(bytes)
        buf.rewind()
        val base = BaseOptions.builder().setModelAssetBuffer(buf).build()
        val opts = HandLandmarker.HandLandmarkerOptions.builder()
            .setBaseOptions(base)
            .setRunningMode(RunningMode.VIDEO)
            .setNumHands(1)
            .setMinHandDetectionConfidence(0.6f)
            .setMinHandPresenceConfidence(0.5f)
            .setMinTrackingConfidence(0.5f)
            .build()
        landmarker = HandLandmarker.createFromOptions(ctx, opts)
    }

    fun ratio(bmp: Bitmap): Float? {
        var ts = SystemClock.uptimeMillis()
        if (ts <= lastTs) ts = lastTs + 1
        lastTs = ts
        val res = landmarker.detectForVideo(BitmapImageBuilder(bmp).build(), ts)
        val l = res.landmarks().firstOrNull() ?: return null
        val ar = bmp.width.toFloat() / bmp.height.toFloat()
        fun d(a: Int, b: Int): Float {
            val dx = (l[a].x() - l[b].x()) * ar
            val dy = l[a].y() - l[b].y()
            return sqrt(dx * dx + dy * dy)
        }
        val palm = d(0, 9)
        if (palm < 1e-4f) return null
        val sum = d(0, 8) + d(0, 12) + d(0, 16) + d(0, 20)
        return (sum / 4f) / palm
    }

    fun close() {
        try { landmarker.close() } catch (_: Exception) {}
    }
}
