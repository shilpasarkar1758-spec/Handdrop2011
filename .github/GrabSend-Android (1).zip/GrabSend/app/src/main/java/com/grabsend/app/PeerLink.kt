package com.grabsend.app

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.net.wifi.WifiManager
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Phone-to-phone link over the local Wi-Fi network.
 * Both phones advertise "gs-<pinHash>-<id>" via NSD and listen on a TCP port. Only phones with the
 * same PIN see each other. The phone with the smaller id connects; the other accepts. If the link
 * drops it reconnects automatically.
 */
class PeerLink(
    ctx: Context,
    private val pinHash: String,
    private val myId: String,
    private val cb: Callback
) {
    interface Callback {
        fun onLinkState(connected: Boolean)
        fun onGrab(jpeg: ByteArray)
        fun onCancel()
        fun onGot()
    }

    companion object {
        const val T_HELLO: Byte = 1
        const val T_GRAB: Byte = 2
        const val T_CANCEL: Byte = 3
        const val T_GOT: Byte = 4
        const val T_PING: Byte = 5
        const val MAX = 25_000_000
        const val SVC = "_grabsend._tcp"
    }

    private val app = ctx.applicationContext
    private val nsd = app.getSystemService(Context.NSD_SERVICE) as NsdManager
    private val wifi = app.getSystemService(Context.WIFI_SERVICE) as WifiManager
    private var mcast: WifiManager.MulticastLock? = null
    private var server: ServerSocket? = null

    @Volatile private var closed = false
    @Volatile private var sock: Socket? = null
    @Volatile private var out: DataOutputStream? = null
    @Volatile private var ready = false
    private val sendLock = Any()
    private val io = Executors.newCachedThreadPool()
    private val tx = Executors.newSingleThreadExecutor()
    private val sched = Executors.newSingleThreadScheduledExecutor()
    private val connecting = AtomicBoolean(false)

    private var regL: NsdManager.RegistrationListener? = null
    private var discL: NsdManager.DiscoveryListener? = null

    @Volatile private var peerHost: InetAddress? = null
    @Volatile private var peerPort = 0
    @Volatile private var peerId = ""
    @Volatile private var peerName = ""

    private val queue = ArrayDeque<NsdServiceInfo>()
    private var resolving = false

    val isConnected: Boolean get() = ready

    fun start() {
        try {
            mcast = wifi.createMulticastLock("grabsend").apply {
                setReferenceCounted(false)
                acquire()
            }
        } catch (_: Exception) {}
        val ss = ServerSocket(0)
        server = ss
        io.execute {
            while (!closed) {
                try {
                    val s = ss.accept()
                    attach(s)
                } catch (e: Exception) {
                    if (closed) break
                }
            }
        }
        register(ss.localPort)
        discover()
        sched.scheduleWithFixedDelay({ tick() }, 5, 5, TimeUnit.SECONDS)
    }

    fun sendGrab(jpeg: ByteArray) { tx.execute { if (ready) writeMsg(T_GRAB, jpeg) } }
    fun sendCancel() { tx.execute { if (ready) writeMsg(T_CANCEL, ByteArray(0)) } }
    fun sendGot() { tx.execute { if (ready) writeMsg(T_GOT, ByteArray(0)) } }

    fun stop() {
        closed = true
        try { regL?.let { nsd.unregisterService(it) } } catch (_: Exception) {}
        try { discL?.let { nsd.stopServiceDiscovery(it) } } catch (_: Exception) {}
        try { sock?.close() } catch (_: Exception) {}
        try { server?.close() } catch (_: Exception) {}
        sched.shutdownNow(); tx.shutdownNow(); io.shutdownNow()
        try { mcast?.release() } catch (_: Exception) {}
    }

    // ---------- connection handling ----------

    private fun tick() {
        if (closed) return
        if (ready) {
            tx.execute { writeMsg(T_PING, ByteArray(0)) }
            return
        }
        val h = peerHost
        if (h != null && myId < peerId && sock == null) connectAsync(h, peerPort)
    }

    private fun connectAsync(h: InetAddress, p: Int) {
        if (!connecting.compareAndSet(false, true)) return
        io.execute {
            try {
                val s = Socket()
                s.connect(InetSocketAddress(h, p), 4000)
                if (closed) { s.close(); return@execute }
                attach(s)
            } catch (_: Exception) {
            } finally {
                connecting.set(false)
            }
        }
    }

    private fun attach(s: Socket) {
        val old = sock
        sock = null; out = null; ready = false
        try { old?.close() } catch (_: Exception) {}
        try {
            s.tcpNoDelay = true
            s.keepAlive = true
            s.soTimeout = 20000
        } catch (_: Exception) {}
        val din = DataInputStream(BufferedInputStream(s.getInputStream()))
        out = DataOutputStream(BufferedOutputStream(s.getOutputStream()))
        sock = s
        writeMsg(T_HELLO, pinHash.toByteArray())
        io.execute { readLoop(s, din) }
    }

    private fun writeMsg(type: Byte, data: ByteArray) {
        val o = out ?: return
        synchronized(sendLock) {
            try {
                o.writeByte(type.toInt())
                o.writeInt(data.size)
                o.write(data)
                o.flush()
            } catch (e: Exception) {
                try { sock?.close() } catch (_: Exception) {}
            }
        }
    }

    private fun readLoop(s: Socket, din: DataInputStream) {
        var hello = false
        try {
            while (!closed) {
                val t = din.readByte()
                val len = din.readInt()
                if (len < 0 || len > MAX) break
                val data = ByteArray(len)
                din.readFully(data)
                if (t == T_HELLO) {
                    if (String(data) != pinHash) break
                    hello = true
                    if (sock === s) { ready = true; cb.onLinkState(true) }
                } else if (hello) {
                    when (t) {
                        T_GRAB -> cb.onGrab(data)
                        T_CANCEL -> cb.onCancel()
                        T_GOT -> cb.onGot()
                        else -> {}
                    }
                }
            }
        } catch (_: Exception) {
        } finally {
            try { s.close() } catch (_: Exception) {}
            if (sock === s) {
                sock = null; out = null
                if (ready) { ready = false; cb.onLinkState(false) }
            }
        }
    }

    // ---------- discovery ----------

    private fun register(port: Int) {
        val info = NsdServiceInfo().apply {
            serviceName = "gs-$pinHash-$myId"
            serviceType = SVC
            setPort(port)
        }
        regL = object : NsdManager.RegistrationListener {
            override fun onServiceRegistered(i: NsdServiceInfo) {}
            override fun onRegistrationFailed(i: NsdServiceInfo, code: Int) {}
            override fun onServiceUnregistered(i: NsdServiceInfo) {}
            override fun onUnregistrationFailed(i: NsdServiceInfo, code: Int) {}
        }
        try { nsd.registerService(info, NsdManager.PROTOCOL_DNS_SD, regL) } catch (_: Exception) {}
    }

    private fun discover() {
        discL = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(t: String) {}
            override fun onServiceFound(i: NsdServiceInfo) {
                val n = i.serviceName ?: return
                if (n.startsWith("gs-$pinHash-") && !n.contains(myId)) enqueue(i)
            }
            override fun onServiceLost(i: NsdServiceInfo) {
                if (i.serviceName == peerName) peerHost = null
            }
            override fun onDiscoveryStopped(t: String) {}
            override fun onStartDiscoveryFailed(t: String, code: Int) {}
            override fun onStopDiscoveryFailed(t: String, code: Int) {}
        }
        try { nsd.discoverServices(SVC, NsdManager.PROTOCOL_DNS_SD, discL) } catch (_: Exception) {}
    }

    @Synchronized private fun enqueue(i: NsdServiceInfo) { queue.add(i); next() }

    @Synchronized private fun next() {
        if (resolving || closed) return
        val i = queue.removeFirstOrNull() ?: return
        resolving = true
        try {
            @Suppress("DEPRECATION")
            nsd.resolveService(i, object : NsdManager.ResolveListener {
                override fun onResolveFailed(s: NsdServiceInfo, code: Int) { resolveDone() }
                override fun onServiceResolved(s: NsdServiceInfo) {
                    try { handleResolved(s) } catch (_: Exception) {}
                    resolveDone()
                }
            })
        } catch (e: Exception) {
            resolving = false
        }
    }

    @Synchronized private fun resolveDone() { resolving = false; next() }

    @Suppress("DEPRECATION")
    private fun handleResolved(s: NsdServiceInfo) {
        val name = s.serviceName ?: return
        val parts = name.split("-")
        if (parts.size < 3) return
        val pid = parts[2].take(8)
        val host = s.host ?: return
        peerName = name
        peerId = pid
        peerPort = s.port
        peerHost = host
        if (myId < pid && sock == null) connectAsync(host, s.port)
    }
}
