package com.grabsend.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

/** Shared state read by the UI. */
object ServiceState {
    @Volatile var running = false
    @Volatile var status = "Stopped"
}

fun pinHash(pin: String): String =
    MessageDigest.getInstance("SHA-256")
        .digest(("grabsend:$pin").toByteArray())
        .joinToString("") { "%02x".format(it) }
        .take(8)

/** Images waiting to be sent (already scaled JPEGs). */
object Outbox {
    fun dir(c: Context): File = File(c.filesDir, "outbox").also { it.mkdirs() }

    fun list(c: Context): List<File> =
        (dir(c).listFiles()?.toList() ?: emptyList())
            .filter { it.isFile && it.name.endsWith(".jpg") }
            .sortedBy { it.name }

    fun next(c: Context): File? = list(c).firstOrNull()

    fun clear(c: Context) { list(c).forEach { it.delete() } }

    fun import(c: Context, uri: Uri): Boolean {
        return try {
            val src = ImageDecoder.createSource(c.contentResolver, uri)
            val bmp = ImageDecoder.decodeBitmap(src) { decoder, info, _ ->
                val m = maxOf(info.size.width, info.size.height)
                if (m > 1280) {
                    val s = 1280f / m
                    decoder.setTargetSize(
                        (info.size.width * s).toInt().coerceAtLeast(1),
                        (info.size.height * s).toInt().coerceAtLeast(1)
                    )
                }
                decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            }
            val f = File(dir(c), "${System.currentTimeMillis()}_${(100..999).random()}.jpg")
            f.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 85, it) }
            true
        } catch (e: Exception) {
            false
        }
    }
}

/** MediaPipe hand model, downloaded once on first start. */
object ModelStore {
    private const val MODEL_URL =
        "https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task"

    fun file(c: Context): File = File(c.filesDir, "hand_landmarker.task")

    fun ready(c: Context): Boolean = file(c).let { it.exists() && it.length() > 1_000_000 }

    fun download(c: Context): Boolean {
        return try {
            val tmp = File(c.filesDir, "model.tmp")
            val conn = URL(MODEL_URL).openConnection() as HttpURLConnection
            conn.connectTimeout = 15000
            conn.readTimeout = 30000
            if (conn.responseCode != 200) return false
            conn.inputStream.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
            if (tmp.length() < 1_000_000) {
                tmp.delete()
                false
            } else {
                file(c).delete()
                tmp.renameTo(file(c))
            }
        } catch (e: Exception) {
            false
        }
    }
}
