package com.grabsend.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Matrix
import android.net.Uri
import android.os.Environment
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.MediaStore
import android.util.Log
import android.util.Size
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import java.io.File
import java.util.concurrent.Executors

/**
 * Foreground service: keeps the camera + hand tracking running while the phone is on, and talks to
 * the paired phone. Fist = grab the next queued image and send it. Open hand = receive/drop it.
 */
class GestureService : LifecycleService(), PeerLink.Callback {

    companion object {
        const val ACTION_STOP = "com.grabsend.app.STOP"
        private const val CH_RUN = "run"
        private const val CH_RCV = "rcv"
        private const val ID_RUN = 1
        private const val ID_RCV = 2
        private const val TAG = "GrabSend"
    }

    private enum class St { IDLE, HOLDING }

    private val lock = Any()
    private var state = St.IDLE
    private var holdFile: File? = null
    private var holdAt = 0L
    private var pending: ByteArray? = null
    private var pendAt = 0L
    private var fistN = 0
    private var openN = 0
    private var cooldown = 0L

    private var link: PeerLink? = null
    private var tracker: HandTracker? = null
    private var provider: ProcessCameraProvider? = null
    private val camExec = Executors.newSingleThreadExecutor()
    private var started = false
    private var lastStatus = ""
    private lateinit var prefs: SharedPreferences
    private lateinit var nm: NotificationManager

    override fun onCreate() {
        super.onCreate()
        prefs = getSharedPreferences("gs", Context.MODE_PRIVATE)
        nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_RUN, "Grab & Send running", NotificationManager.IMPORTANCE_LOW)
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_RCV, "Received images", NotificationManager.IMPORTANCE_DEFAULT)
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (started) return START_NOT_STICKY
        started = true
        ServiceState.running = true

        try {
            ServiceCompat.startForeground(
                this, ID_RUN, runNotification("Starting…"),
                ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
            )
        } catch (e: Exception) {
            fail("Cannot start background service: ${e.message}")
            return START_NOT_STICKY
        }

        val pin = prefs.getString("pin", "") ?: ""
        if (pin.length != 4) { fail("Set a 4-digit PIN first."); return START_NOT_STICKY }

        try {
            tracker = HandTracker(this, ModelStore.file(this))
        } catch (e: Throwable) {
            fail("Hand model failed: ${e.message}")
            return START_NOT_STICKY
        }

        try {
            var id = prefs.getString("devId", null)
            if (id == null) {
                id = "%08x".format((Math.random() * 0xFFFFFFFFL).toLong())
                prefs.edit().putString("devId", id).apply()
            }
            link = PeerLink(this, pinHash(pin), id, this).also { it.start() }
        } catch (e: Exception) {
            fail("Network failed: ${e.message}")
            return START_NOT_STICKY
        }

        startCamera()
        setStatus("Looking for the other phone on this Wi-Fi…")
        return START_NOT_STICKY
    }

    private fun fail(msg: String) {
        setStatus(msg)
        stopSelf()
    }

    // ---------------- camera ----------------

    @Suppress("DEPRECATION")
    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                val p = future.get()
                provider = p
                val analysis = ImageAnalysis.Builder()
                    .setTargetResolution(Size(480, 640))
                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()
                analysis.setAnalyzer(camExec) { proxy -> analyze(proxy) }
                val sel = if (prefs.getBoolean("back", false))
                    CameraSelector.DEFAULT_BACK_CAMERA else CameraSelector.DEFAULT_FRONT_CAMERA
                p.unbindAll()
                p.bindToLifecycle(this, sel, analysis)
            } catch (e: Exception) {
                fail("Camera failed: ${e.message}")
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun analyze(proxy: ImageProxy) {
        try {
            val t = tracker ?: return
            val raw = proxy.toBitmap()
            val rot = proxy.imageInfo.rotationDegrees
            val bmp = if (rot == 0) raw else Bitmap.createBitmap(
                raw, 0, 0, raw.width, raw.height,
                Matrix().apply { postRotate(rot.toFloat()) }, true
            )
            handle(t.ratio(bmp))
        } catch (e: Throwable) {
            Log.w(TAG, "frame error", e)
        } finally {
            proxy.close()
        }
    }

    // ---------------- gesture logic ----------------

    private fun handle(ratio: Float?) {
        synchronized(lock) {
            val now = SystemClock.elapsedRealtime()
            if (state == St.HOLDING && now - holdAt > 45000) cancelHold("Took too long — put the image back.")
            if (ratio == null) { fistN = 0; openN = 0; return }
            val sens = prefs.getFloat("sens", 1.3f)
            if (ratio < sens) { fistN++; openN = 0 }
            else if (ratio > 1.6f) { openN++; fistN = 0 }
            else { fistN = 0; openN = 0 }

            if (state == St.IDLE && pending == null && fistN >= 3 && now > cooldown) grab(now)
            if (state == St.HOLDING && now - holdAt > 2500 && openN >= 6) cancelHold("Put the image back.")
            val p = pending
            if (p != null && now - pendAt > 1200 && openN >= 4) reveal(p, now)
        }
    }

    private fun grab(now: Long) {
        val l = link
        if (l == null || !l.isConnected) {
            cooldown = now + 2500
            setStatus("Not connected to the other phone yet.")
            return
        }
        val f = Outbox.next(this)
        if (f == null) {
            cooldown = now + 3000
            setStatus("No images queued. Add some in the app.")
            return
        }
        val bytes = try { f.readBytes() } catch (e: Exception) { f.delete(); return }
        l.sendGrab(bytes)
        state = St.HOLDING
        holdFile = f
        holdAt = now
        fistN = 0
        vibrate(60)
        setStatus("✊ Got it! Carry it to the other phone and open your hand.")
    }

    private fun cancelHold(msg: String) {
        if (state != St.HOLDING) return
        state = St.IDLE
        holdFile = null
        link?.sendCancel()
        cooldown = SystemClock.elapsedRealtime() + 2000
        vibrate(30)
        setStatus(msg)
    }

    private fun reveal(bytes: ByteArray, now: Long) {
        pending = null
        openN = 0
        cooldown = now + 3000
        val uri = saveToGallery(bytes)
        link?.sendGot()
        vibrate(80)
        if (uri != null) {
            notifyReceived(uri)
            setStatus("Received ✓ Saved to Pictures/GrabSend")
        } else {
            setStatus("Received, but saving failed.")
        }
    }

    // ---------------- PeerLink callbacks (network threads) ----------------

    override fun onLinkState(connected: Boolean) {
        synchronized(lock) {
            if (!connected) {
                pending = null
                if (state == St.HOLDING) { state = St.IDLE; holdFile = null }
                setStatus("Connection lost. Reconnecting automatically…")
            } else {
                setStatus("Connected ✓ Make a fist to grab, open your hand to receive.")
                vibrate(30)
            }
        }
    }

    override fun onGrab(jpeg: ByteArray) {
        synchronized(lock) {
            pending = jpeg
            pendAt = SystemClock.elapsedRealtime()
            openN = 0
            vibrate(40)
            setStatus("✋ Image coming! Open your hand in front of the camera.")
        }
    }

    override fun onCancel() {
        synchronized(lock) {
            pending = null
            setStatus("The other phone put the image back.")
        }
    }

    override fun onGot() {
        synchronized(lock) {
            if (state != St.HOLDING) return
            state = St.IDLE
            holdFile?.delete()
            holdFile = null
            cooldown = SystemClock.elapsedRealtime() + 3000
            vibrate(80)
            val left = Outbox.list(this).size
            setStatus(if (left > 0) "✅ Delivered! $left image(s) left." else "✅ Delivered! Queue is empty.")
        }
    }

    // ---------------- saving / notifications ----------------

    private fun saveToGallery(bytes: ByteArray): Uri? {
        return try {
            val v = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "grab-send-${System.currentTimeMillis()}.jpg")
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/GrabSend")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v) ?: return null
            contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
            v.clear()
            v.put(MediaStore.Images.Media.IS_PENDING, 0)
            contentResolver.update(uri, v, null, null)
            uri
        } catch (e: Exception) {
            Log.w(TAG, "save failed", e)
            null
        }
    }

    private fun notifyReceived(uri: Uri) {
        try {
            val view = Intent(Intent.ACTION_VIEW).setDataAndType(uri, "image/jpeg")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            val pi = PendingIntent.getActivity(
                this, 1, view, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val n = NotificationCompat.Builder(this, CH_RCV)
                .setSmallIcon(android.R.drawable.ic_menu_gallery)
                .setContentTitle("Image received")
                .setContentText("Tap to open")
                .setContentIntent(pi)
                .setAutoCancel(true)
                .build()
            nm.notify(ID_RCV, n)
        } catch (_: Exception) {}
    }

    private fun runNotification(text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 2, Intent(this, GestureService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CH_RUN)
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentTitle("Grab & Send is active")
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(open)
            .addAction(0, "Stop", stop)
            .build()
    }

    private fun setStatus(s: String) {
        ServiceState.status = s
        if (s != lastStatus && started) {
            lastStatus = s
            try { nm.notify(ID_RUN, runNotification(s)) } catch (_: Exception) {}
        }
    }

    @Suppress("DEPRECATION")
    private fun vibrate(ms: Long) {
        try {
            val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (_: Exception) {}
    }

    override fun onDestroy() {
        started = false
        ServiceState.running = false
        try { provider?.unbindAll() } catch (_: Exception) {}
        link?.stop()
        tracker?.close()
        camExec.shutdown()
        stopForeground(STOP_FOREGROUND_REMOVE)
        ServiceState.status = if (ServiceState.status.startsWith("Cannot") ||
            ServiceState.status.contains("failed") || ServiceState.status.startsWith("Set a")
        ) ServiceState.status else "Stopped"
        super.onDestroy()
    }
}
