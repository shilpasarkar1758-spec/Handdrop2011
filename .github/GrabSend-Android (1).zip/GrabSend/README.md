# Grab & Send (Android)

Fist on phone A = grab the next queued image. Open hand in front of phone B = drop it there.
Runs as a foreground service ("Grab & Send is active" notification) so gestures work while you use
other apps, as long as the phone is on and unlocked.

## Build
1. Install Android Studio (Koala 2024.1 or newer).
2. File > Open > select this `GrabSend` folder. Let Gradle sync.
3. Plug in a phone (USB debugging on) and press Run. Repeat for the second phone.
   (Or Build > Build APK(s) and install the APK on both phones.)

## Use
1. Put both phones on the same Wi-Fi (or one phone's hotspot).
2. On both: open the app, type the SAME 4-digit PIN, press Start. First start downloads the hand
   model (~8 MB, needs internet) and asks for camera + notification permission.
3. On the sending phone: Add images. Phones find each other and reconnect automatically after this.
4. Fist over phone A to grab. Open your hand over phone B to receive. Images are saved in
   Pictures/GrabSend and a notification opens them.

## Notes
- Android blocks camera access when the screen is off/locked.
- If it stops after a while, set battery to "Unrestricted" for Grab & Send in system settings.
- Wi-Fi with "client isolation" (guest/public networks) blocks phone-to-phone traffic.
- Traffic is local-network only, unencrypted, and gated by the PIN.
