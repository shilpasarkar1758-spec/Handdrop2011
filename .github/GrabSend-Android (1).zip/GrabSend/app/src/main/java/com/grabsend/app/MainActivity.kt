package com.grabsend.app

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.text.InputFilter
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var statusTv: TextView
    private lateinit var queueTv: TextView
    private lateinit var startBtn: Button
    private lateinit var pinEt: EditText
    private val ui = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() { refresh(); ui.postDelayed(this, 700) }
    }

    private val pickImages =
        registerForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
            if (uris.isNotEmpty()) {
                Thread {
                    var ok = 0
                    uris.forEach { if (Outbox.import(this, it)) ok++ }
                    runOnUiThread {
                        toast("Added $ok of ${uris.size} image(s)")
                        refresh()
                    }
                }.start()
            }
        }

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            if (granted(Manifest.permission.CAMERA)) beginStart()
            else toast("Camera permission is required.")
        }

    private fun granted(p: String) =
        ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("gs", Context.MODE_PRIVATE)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(20), dp(28), dp(20), dp(28))

        fun text(t: String, size: Float = 14f, top: Int = 14): TextView {
            val tv = TextView(this)
            tv.text = t
            tv.textSize = size
            tv.setPadding(0, dp(top), 0, dp(4))
            return tv
        }

        root.addView(text("Grab & Send", 26f, 0))
        root.addView(text("Make a fist to grab the next queued image. Open your hand in front of the other phone to drop it there."))

        statusTv = text("Stopped", 16f, 18)
        root.addView(statusTv)

        startBtn = Button(this)
        startBtn.text = "Start"
        startBtn.setOnClickListener { onStartStop() }
        root.addView(startBtn)

        root.addView(text("Pairing PIN (type the same 4 digits on both phones)", 14f, 22))
        pinEt = EditText(this)
        pinEt.inputType = InputType.TYPE_CLASS_NUMBER
        pinEt.filters = arrayOf(InputFilter.LengthFilter(4))
        pinEt.setText(prefs.getString("pin", ""))
        root.addView(pinEt)

        root.addView(text("Images to send", 14f, 22))
        queueTv = text("", 14f, 0)
        root.addView(queueTv)
        val addBtn = Button(this)
        addBtn.text = "Add images"
        addBtn.setOnClickListener { pickImages.launch("image/*") }
        root.addView(addBtn)
        val clearBtn = Button(this)
        clearBtn.text = "Clear queue"
        clearBtn.setOnClickListener { Outbox.clear(this); refresh() }
        root.addView(clearBtn)

        val sensTv = text("", 14f, 22)
        root.addView(sensTv)
        val sens = SeekBar(this)
        sens.max = 70
        fun showSens(v: Float) { sensTv.text = "Fist sensitivity: %.2f (higher = easier to trigger)".format(v) }
        val cur = prefs.getFloat("sens", 1.3f)
        sens.progress = ((cur - 0.9f) * 100f).toInt().coerceIn(0, 70)
        showSens(cur)
        sens.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                val v = 0.9f + p / 100f
                showSens(v)
                if (fromUser) prefs.edit().putFloat("sens", v).apply()
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        root.addView(sens)

        val back = Switch(this)
        back.text = "Use back camera (restart to apply)"
        back.isChecked = prefs.getBoolean("back", false)
        back.setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean("back", c).apply() }
        back.setPadding(0, dp(16), 0, dp(4))
        root.addView(back)

        root.addView(text(
            "Both phones must be on the same Wi-Fi (or one phone's hotspot). Gestures work while the " +
            "phone is on and unlocked, even when other apps are open. When the screen is off or " +
            "locked, Android blocks the camera.", 12f, 24
        ))

        root.layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        )
        val sv = ScrollView(this)
        sv.addView(root)
        setContentView(sv)
        refresh()
    }

    override fun onResume() { super.onResume(); ui.post(tick) }
    override fun onPause() { super.onPause(); ui.removeCallbacks(tick) }

    private fun refresh() {
        statusTv.text = ServiceState.status
        startBtn.text = if (ServiceState.running) "Stop" else "Start"
        val n = Outbox.list(this).size
        queueTv.text = if (n == 0) "No images queued." else "$n image(s) queued."
    }

    private fun onStartStop() {
        if (ServiceState.running) {
            startService(Intent(this, GestureService::class.java).setAction(GestureService.ACTION_STOP))
            return
        }
        val need = mutableListOf<String>()
        if (!granted(Manifest.permission.CAMERA)) need.add(Manifest.permission.CAMERA)
        if (Build.VERSION.SDK_INT >= 33 && !granted(Manifest.permission.POST_NOTIFICATIONS))
            need.add(Manifest.permission.POST_NOTIFICATIONS)
        if (need.isEmpty()) beginStart() else permLauncher.launch(need.toTypedArray())
    }

    private fun beginStart() {
        val pin = pinEt.text.toString().trim()
        if (!Regex("\\d{4}").matches(pin)) {
            toast("Enter a 4-digit PIN (same on both phones).")
            return
        }
        prefs.edit().putString("pin", pin).apply()
        startBtn.isEnabled = false
        Thread {
            var ok = ModelStore.ready(this)
            if (!ok) {
                ServiceState.status = "Downloading hand model (one time, needs internet)…"
                ok = ModelStore.download(this)
            }
            runOnUiThread {
                startBtn.isEnabled = true
                if (!ok) {
                    ServiceState.status = "Could not download the hand model. Check internet and try again."
                } else {
                    ContextCompat.startForegroundService(this, Intent(this, GestureService::class.java))
                }
                refresh()
            }
        }.start()
    }
}
